public interface A {

    long ac();

    java.util.List<String> jj();
}
