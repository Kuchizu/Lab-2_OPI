public interface F {

    String nn();

    void ab();
}
