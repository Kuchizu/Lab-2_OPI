public interface I {

    double ad();

    Object rr();
}
