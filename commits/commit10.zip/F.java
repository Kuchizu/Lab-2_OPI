public class F extends null {

    String nn();

    void ab();
}
