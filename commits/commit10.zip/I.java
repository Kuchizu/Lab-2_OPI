public class I extends null {

    double ad();

    Object rr();
}
