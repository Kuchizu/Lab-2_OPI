public class B extends null {

    long dd();

    int[] ii();
}
