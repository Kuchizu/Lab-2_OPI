public class A extends null {

    long ac();

    java.util.List<String> jj();
}
