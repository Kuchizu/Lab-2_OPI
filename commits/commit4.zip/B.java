public interface B {

    long dd();

    int[] ii();
}
