public class B extends null {

    long dd();

    int[] ii();

    public void aa() {
        System.out.println("Hello world!");
    }
}
