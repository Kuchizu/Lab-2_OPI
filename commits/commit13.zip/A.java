public class A extends null {

    long ac();

    java.util.List<String> jj();

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
