public class F extends null {

    String nn();

    void ab();

    public byte oo() {
        return 4;
    }
}
