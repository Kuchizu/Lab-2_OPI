public class I extends null {

    double ad();

    Object rr();

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }
}
